<?php
namespace frontend\modules\v1\mosquitto\config;

class ServerProperties
{
    const _SERVER = "127.0.0.1";
    const _PORT = 1883;
}